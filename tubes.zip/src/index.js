import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./style/main.css";
import "./scripts/component/nav-bar.js";
import "./scripts/component/jumbotron.js";
import main from "./scripts/view/main";
main();