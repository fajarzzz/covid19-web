import getDataConfirmed from '../data/getData.js';
const main = () => {
    window.addEventListener('load', () => {
        getDataConfirmed();
    });
};
export default main;