# Covid19-web
Covid-19 Information Website, Build with NodeJS.

Consume API : https://github.com/mathdroid/covid-19-api

## RUN Web Application
  Require : NPM NodeJS
  
  To run:
  ```
  npm install
  npm run start-dev
  ```
